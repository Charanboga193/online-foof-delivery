﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Online_Food_Delivery_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Food_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ItemsController : ControllerBase
    {
        private readonly OFDDBContext _context;

        public ItemsController(OFDDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IEnumerable<Item> GetItems()
        {
            return _context.Items.ToList();
        }


        [HttpGet("{id}")]
        public Item GetItem(int id)
        {
            var item = _context.Items.Find(id);

            if (item == null)
            {
                return new Item();
            }

            return item;
        }


        [HttpPost]
        public void PostItem([FromBody] Item item)
        {
            _context.Items.Add(item);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutItem(int id, [FromBody] Item item)
        {
            _context.Entry(item).State = EntityState.Modified;
            _context.SaveChanges();
        }


        [HttpDelete("{id}")]
        public bool DeleteItem(int id)
        {
            var item = _context.Items.Find(id);
            if (item == null)
            {
                return false;
            }

            _context.Items.Remove(item);
            _context.SaveChanges();
            return true;

        }

    }
}
