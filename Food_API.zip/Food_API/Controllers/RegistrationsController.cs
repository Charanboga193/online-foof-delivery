﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Online_Food_Delivery_DAO;

namespace Food_API.Controllers
{
    public class RegistrationsController : Controller
    {
        private readonly OFDDBContext _context;

        public RegistrationsController(OFDDBContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Registration> GetRegistrations()
        {
            return _context.Registrations.ToList();
        }


        [HttpGet("{id}")]
        public Registration GetRegistration(int id)
        {
            var registration = _context.Registrations.Find(id);

            if (registration == null)
            {
                return new Registration();
            }

            return registration;
        }

        // POST: RegistrationController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public void PostRegistration([FromBody] Registration registration)
        {
            _context.Registrations.Add(registration);
            _context.SaveChanges();
        }

        [HttpPut("{id}")]
        public void PutRegistration(int id, [FromBody] Registration registration)
        {
            _context.Entry(registration).State = EntityState.Modified;
            _context.SaveChanges();
        }


        [HttpDelete("{id}")]
        public bool DeleteRegistration(int id)
        {
            var registration = _context.Registrations.Find(id);
            if (registration == null)
            {
                return false;
            }

            _context.Registrations.Remove(registration);
            _context.SaveChanges();
            return true;
        }
    }
}
