﻿using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Online_Food_Delivery_DAO;


// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Food_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminsController : ControllerBase
    {
        private readonly OFDDBContext _context;

        public AdminsController(OFDDBContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Admin> GetAdmins()
        {
            return _context.Admins.ToList();
        }


        [HttpGet("{id}")]
        public Admin GetAdmin(int id)
        {
            var admin = _context.Admins.Find(id);

            if (admin == null)
            {
                return new Admin();
            }

            return admin;
        }


        [HttpPost]
        public void PostAdmin([FromBody] Admin admin)
        {
            _context.Admins.Add(admin);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutAdmin(int id, [FromBody] Admin admin)
        {
            _context.Entry(admin).State = EntityState.Modified;
            _context.SaveChanges();
        }


        [HttpDelete("{id}")]
        public bool DeleteAdmin(int id)
        {
            var admin = _context.Admins.Find(id);
            if (admin == null)
            {
                return false;
            }

            _context.Admins.Remove(admin);
            _context.SaveChanges();
            return true;

        }
     
    }
}
