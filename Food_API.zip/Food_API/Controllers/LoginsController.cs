﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Online_Food_Delivery_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Food_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class LoginController : ControllerBase
    {
        private readonly OFDDBContext _context;

        public LoginController(OFDDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IEnumerable<Login> GetLogins()
        {
            return _context.Logins.ToList();
        }


        [HttpGet("{id:int}")]
        public Login GetLogin(int id)
        {
            var login = _context.Logins.Find(id);

            if (login == null)
            {
                return new Login();
            }

            return login;
        }

        [HttpGet("{username}/{password}")]
        public string CheckLogin(string username, string password)
        {
            var login = _context.Logins.FirstOrDefault(m => (m.UserName == username && m.Password == password));
            if (login != null)
            {
                if (login.LoginType == null)
                {
                    return "";
                }
                else
                {
                    return login.LoginType;
                }
            }
            return "";
           
        }

        [HttpGet("{username}")]
        public string ForgotPwd(string username)
        {
            var login = _context.Logins.FirstOrDefault(m => (m.UserName == username));
            if (login != null)
            {
                if (login.Password == null)
                {
                    return "";
                }
                else
                {
                    return login.Password;
                }
            }
            return "";

        }


        [HttpPost]
        public void PosLogin([FromBody] Login login)
        {
            _context.Logins.Add(login);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutLogin(int id, [FromBody] Login login)
        {
            _context.Entry(login).State = EntityState.Modified;
            _context.SaveChanges();
        }


        [HttpDelete("{id}")]
        public bool DeleteLogin(int id)
        {
            var login = _context.Logins.Find(id);
            if (login == null)
            {
                return false;
            }

            _context.Logins.Remove(login);
            _context.SaveChanges();
            return true;

        }
    }
}
