﻿using Microsoft.AspNetCore.Mvc;
using Online_Food_Delivery_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

/*namespace Food_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilitesController : ControllerBase
    {
        private readonly OFDDBContext _context;

        public UtilitesController(OFDDBContext context)
        {
            _context = context;
        }
        // GET: api/<UtilitesController>
        [HttpGet("{id}")]
        public IEnumerable<Order> Display_historical_list(int id)
        {
            return _context.Orders.Where(m => m.CustomerId == id);
        }

        // GET api/<UtilitesController>/5
        [HttpGet("{area}")]
        public IEnumerable<Item> Search_Food_By_Area(string area)
        {
            return _context.Items.Where(m => m.area == area);
        }

        [HttpGet("{location}")]
        public IEnumerable<Item> Search_Food_By_Location(string location)
        {
            return _context.Items.Where(m => m.location == location);
        }
        [HttpGet("{city}")]
        public IEnumerable<Item> Search_Food_By_city(string city)
        {
            return _context.Items.Where(m => m.city == city);
        }
        [HttpGet("{RestId}")]
        public IEnumerable<Item> Search_Food_By_Restaurant(int RestId)
        {
            return _context.Items.Where(m => m.RestaurantId == RestId);
        }
        [HttpGet]
        public IEnumerable<OrderDetail> Display_most_popular()
        {
            return _context.OrderDetails.OrderByDescending(x => x.ItemId).Take(5);
        }
        // POST api/<UtilitesController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<UtilitesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<UtilitesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
*/