﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Online_Food_Delivery_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Food_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly OFDDBContext _context;

        public OrdersController(OFDDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IEnumerable<Order> GetOrders()
        {
            return _context.Orders.ToList();
        }


        [HttpGet("{id}")]
        public Order GetOrder(int id)
        {
            var order = _context.Orders.Find(id);

            if (order == null)
            {
                return new Order();
            }

            return order;
        }


        [HttpPost]
        public void PostOrder([FromBody] Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutOrder(int id, [FromBody] Order order)
        {
            _context.Entry(order).State = EntityState.Modified;
            _context.SaveChanges();
        }


        [HttpDelete("{id}")]
        public bool DeleteOrder(int id)
        {
            var order = _context.Orders.Find(id);
            if (order == null)
            {
                return false;
            }

            _context.Orders.Remove(order);
            _context.SaveChanges();
            return true;

        }
    }
}
