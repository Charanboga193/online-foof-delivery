﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Online_Food_Delivery_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Food_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RatingsController : ControllerBase
    {
        private readonly OFDDBContext _context;

        public RatingsController(OFDDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IEnumerable<Rating> GetRatings()
        {
            return _context.Ratings.ToList();
        }


        [HttpGet("{id}")]
        public Rating GetRating(int id)
        {
            var rating = _context.Ratings.Find(id);

            if (rating == null)
            {
                return new Rating();
            }

            return rating;
        }


        [HttpPost]
        public void PostRating([FromBody] Rating rating)
        {
            _context.Ratings.Add(rating);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutRating(int id, [FromBody] Rating rating)
        {
            _context.Entry(rating).State = EntityState.Modified;
            _context.SaveChanges();
        }


        [HttpDelete("{id}")]
        public bool DeleteRating(int id)
        {
            var rating = _context.Ratings.Find(id);
            if (rating == null)
            {
                return false;
            }

            _context.Ratings.Remove(rating);
            _context.SaveChanges();
            return true;

        }
    }
}
