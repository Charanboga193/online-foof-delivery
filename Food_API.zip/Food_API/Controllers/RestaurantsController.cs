﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Online_Food_Delivery_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Food_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RestaurantsController : ControllerBase
    {
        private readonly OFDDBContext _context;

        public RestaurantsController(OFDDBContext context)
        {
            _context = context;
        }
        [HttpGet]
        public IEnumerable<Restaurant> GetRestaurants()
        {
            return _context.Restaurants.ToList();
        }


        [HttpGet("{id}")]
        public Restaurant GetRestaurant(int id)
        {
            var rest = _context.Restaurants.Find(id);

            if (rest == null)
            {
                return new Restaurant();
            }

            return rest;
        }


        [HttpPost]
        public void PostRestaurant([FromBody] Restaurant rest)
        {
            _context.Restaurants.Add(rest);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutRestaurant(int id, [FromBody] Restaurant rest)
        {
            _context.Entry(rest).State = EntityState.Modified;
            _context.SaveChanges();
        }


        [HttpDelete("{id}")]
        public bool DeleteRestaurant(int id)
        {
            var rest = _context.Restaurants.Find(id);
            if (rest == null)
            {
                return false;
            }

            _context.Restaurants.Remove(rest);
            _context.SaveChanges();
            return true;

        }
    }
}
